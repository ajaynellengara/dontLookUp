<section id="Gateway">
    <div class="tleWrap center">
        <h4 class="mHd">Your Gateway to Fashion <br> expertise and Success</h4>
    </div>
    <div class="swiper gatewaySlide">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <div class="gatewayBx">
                    <img src="assets/images/gateway-1.webp" width="150" height="272" loading="lazy" alt="experise">
                </div>
            </div>
            <div class="swiper-slide">
                <div class="gatewayBx">
                    <img src="assets/images/gateway-2.webp" width="150" height="272" loading="lazy" alt="experise">
                </div>
            </div>
            <div class="swiper-slide">
                <div class="gatewayBx">
                    <img src="assets/images/gateway-3.webp" width="150" height="272" loading="lazy" alt="experise">
                </div>
            </div>
            <div class="swiper-slide">
                <div class="gatewayBx">
                    <img src="assets/images/gateway-4.webp" width="150" height="272" loading="lazy" alt="experise">
                </div>
            </div>
            <div class="swiper-slide">
                <div class="gatewayBx">
                    <img src="assets/images/gateway-5.webp" width="150" height="272" loading="lazy" alt="experise">
                </div>
            </div>
            <div class="swiper-slide">
                <div class="gatewayBx">
                    <img src="assets/images/gateway-6.webp" width="150" height="272" loading="lazy" alt="experise">
                </div>
            </div>
            <div class="swiper-slide">
                <div class="gatewayBx">
                    <img src="assets/images/gateway-7.webp" width="150" height="272" loading="lazy" alt="experise">
                </div>
            </div>
        </div>
    </div>
</section>
