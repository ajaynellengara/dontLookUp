<div class="accordion-item">
    <div class="accordion-header">
        <a href="index.php"
            class="accordion-button"
            aria-label="home">
            <span>Home</span>
        </a>
    </div>
</div>
<div class="accordion-item">
    <div class="accordion-header">
        <a href="about.php"
            class="accordion-button"
            aria-label="about">
            <span>About DLU</span>
        </a>
    </div>
</div>
<div class="accordion-item">
    <div class="accordion-header">
        <a href="course.php"
            class="accordion-button"
            aria-label="course">
            <span>Course</span>
        </a>
    </div>
</div>
<div class="accordion-item">
    <div class="accordion-header">
        <a href="about.php"
            class="accordion-button"
            aria-label="about">
            <span>ABOUT US</span>
        </a>
    </div>
</div>
<div class="accordion-item">
    <div class="accordion-header">
        <a href="workshops.php"
            class="accordion-button"
            aria-label="workshops">
            <span>workshops</span>
        </a>
    </div>
</div>
<div class="accordion-item">
    <div class="accordion-header">
        <a href="lifeatdlu.php"
            class="accordion-button"
            aria-label="lifeatdlu">
            <span>Life at DLU</span>
        </a>
    </div>
</div>
<div class="accordion-item">
    <div class="accordion-header">
        <a href="contact.php"
            class="accordion-button"
            aria-label="contact">
            <span>Contact</span>
        </a>
    </div>
</div>