<section id="JoinAcademy">
    <div class="container">
        <div class="joinAcademyBx">
            <div class="cntWrap">
                <div class="tleWrap center">
                    <h6 class="mTxt gsap_splitting_txt">Ready to Shape Your Future in Fashion & Events?</h6>
                    <h4 class="mHd gsap_splitting_txt">Join DLU Academy Today!</h4>
                </div>
                <div class="btnWrap">
                    <a href="index.php" class="baseBtn_1 hoveranim" aria-label="learn">
                        <span>Explore more</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>