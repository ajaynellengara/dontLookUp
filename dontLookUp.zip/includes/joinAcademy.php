<section id="JoinAcademy">
    <div class="container">
        <div class="joinAcademyBx">
            <div class="cntWrap">
                <div class="tleWrap center">
                    <h6 class="mTxt gsap_splitting_txt">Ready to Shape Your Future</h6>
                    <h4 class="mHd gsap_splitting_txt">Join DLU Academy Today!</h4>
                </div>
                <div class="btnWrap">
                    <a href="enrolNow.php" class="baseBtn_1 hoveranim" aria-label="learn">
                        <span>enrol now</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>